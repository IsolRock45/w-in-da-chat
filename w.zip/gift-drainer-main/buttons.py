from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

language_buttons = InlineKeyboardMarkup(row_width=2).add(
    InlineKeyboardButton("Русский", callback_data='lang:ru'),
    InlineKeyboardButton("English", callback_data='lang:en')
)